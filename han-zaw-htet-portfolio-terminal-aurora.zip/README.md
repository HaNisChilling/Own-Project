# Han Zaw Htet — Portfolio ("Terminal Aurora" build)

A single-file, dependency-free portfolio (`index.html`). No build step — open it
directly in a browser, or drop it on any static host (Cloudflare Pages, Netlify,
Vercel, GitHub Pages).

## Deploying

**Cloudflare Pages (drag-and-drop):** dash.cloudflare.com → Workers & Pages →
Create → Pages → Upload assets → name the project → drag this zip in → Deploy.
`index.html` is at the root of the zip, so it is served as the homepage with no
configuration. Limits: 25 MiB per file, 1,000 files. To update, use **Create
deployment** and upload a new zip — individual files cannot be replaced.

To offer the `.pbix` as a download, put it in the same folder as `index.html`,
re-zip, and redeploy. It is then served at `/<filename>.pbix`.

## Structure

The whole site is one HTML file: the "Terminal Aurora" stylesheet reproduced
verbatim, a clearly-labelled `SUPPLEMENTARY ADDITIONS` CSS block, hand-authored
markup, and a `<script>` holding the data and the render functions.

Edit these objects near the top of the script to change content without touching
markup:

- `PROJECTS` — every project card and its modal (title, summary, description,
  role, tags, metrics, pages, code samples, stage tiers, links).
- `TECH_STACK` / `TECH_ICONS` — the tech grid and its icons.
- `LEARNING` / `CORE` — the Currently Learning section and its capstone.
- `SCENARIO_ICONS`, `THUMBS` — per-project thumbnail and scenario art.
- `INITIAL_PROJECT_COUNT` — how many cards show before "View All Projects".
  Currently 10, above the 9 real projects, so the button stays hidden.
  The "N PROJECTS" label above the grid is derived from `PROJECTS.length`, so
  adding a project updates it on its own.

Hero copy, timelines, About text and footer links are static markup — edit them
in place.

## Content notes (real data, no fabrication)

- Contact: `hanzaw110@outlook.com`, LinkedIn `han-zaw-htet-647489239`,
  `+66 94 794 0829`. No GitHub was supplied, so no GitHub link is shown.
- Hobbies are the three supplied — Football, Travel, EDM Music — each with a
  small inline-SVG icon in the accent colour. No placeholders remain.
- Coursework projects (SQL, Snowflake, Python, R & Statistics, Scala) are marked
  with COURSEWORK / PRACTICE badges and self-study attribution, and stage tiers
  carry honest ENROLLED / PLANNED / QUEUED status rather than implied completion.
- The Currently Learning capstone states plainly which experiments are designed
  but not yet run.
- Projects with no real URL use `demo: null` / `code: null` / `caseStudy: null`,
  which renders a disabled, non-clickable action instead of a dead link.
- The hero photo is the real portrait supplied, embedded as base64 so the file
  stays portable. The "HZ · DATA · AI · AUTOMATION" badge is baked into the image
  itself, so it is not duplicated as an overlay. The frame uses `object-fit:
  cover` to match the supplied hero reference; a commented line in the CSS shows
  how to switch back to `contain` for a zero-crop full frame.

## The automation projects

Two, each with its own generated SVG thumbnail:

- **The Smartest Way to Deliver Office Daily Tasks Using Power Automate** — five
  Power Automate flows in one project.
  - *Flow 1* — recurrence → export the Power BI report to PDF → convert to JPEG →
    upload through Microsoft Graph → post into a Teams channel.
  - *Flow 2* — a Forms response triggers conditions and a switch that append each
    matching document to an attachment array, so one email carries every file the
    person selected.
  - *Flow 3* — request triage: a form trigger, a completeness condition, a keyword
    filter (`reporting`, `ad hoc`) that classifies the work, and a switch whose
    Accept case logs, records, notifies Teams and confirms status to the
    requester — while the other path replies honestly that it cannot be taken
    this cycle. Every branch ends in a message.

  - *Flow 4* — marketing product request: a Switch routes on the product itself
    (four cases plus a Default), a Condition tests whether the decision contains
    `Approve`, and on approval the flow allocates an owner, creates the Planner
    task automatically and notifies requester, assignee and team. The decline
    branch answers the requester immediately.

  - *Flow 5* — monthly search-keyword report: a Recurrence, an HTTP action
    carrying the SQL that ranks the most-searched products from the application's
    search log, Parse JSON, a second paged call behind a Delay, then Compose
    builds CSV which is converted to XLSX and delivered to the product team.

  All five flow screenshots sit in the gallery grid, capped at 460px tall with
  `object-fit: contain` and `align-items: start`, so flows of different shapes
  share rows without dead space.
- **Intelligent AI Automation — Self-Running Data Workflows** — three n8n
  workflows plus the instance they run in, shown as four captured screenshots.
  - *Inventory BI* — schedule → read inventory → validate → data-quality branch →
    calculate KPIs → **Gemini analysis** → store metrics → refresh the Power BI
    dataset → wait → check the refresh history → executive email written by the
    model, or a refresh-failure alert. A separate low-stock check raises its own
    alert.
  - *Customer support agent* — Gmail trigger → classify (promotional vs support)
    → an AI agent with chat model, memory and a **vector store on Gemini
    embeddings (RAG)** → a Gmail draft for a human to approve, plus a Telegram
    notification.
  - *Version control* — schedule → list every workflow → loop → subworkflow that
    diffs each against GitHub and creates, edits or skips. Built on the
    established n8n backup-to-GitHub pattern, configured against my own repo.

  **The AI title is now accurate.** Earlier versions of this project described a
  rule-based nightly validation flow with no model in it. These workflows use
  Gemini for analysis and summary generation, and a vector store for grounded
  retrieval — the title matches the build.

## The Power BI reports

Two competition projects follow the same pattern: captured images of every
report page, plus a one-line link out to the live report through a Power BI
**Publish to web** URL (`app.powerbi.com/view?r=...`), which needs no sign-in.
Neither report is framed on the page, so both render identically everywhere.

- **Bank Churn Report** — five captured pages, First Runner-Up at the Matrix
  Dashboard Challenge.
- **Inventory Management Analysis** — three captured pages, plus a link to the
  LinkedIn post announcing it. Its card thumbnail is a composite of the three
  pages, generated once and embedded as a JPEG.

Note that Publish to web makes the report and its underlying data readable by
anyone with the link. Republishing in Power BI Service updates what the link
shows without changing the link; the captured images are snapshots and need
re-capturing when the report changes.

## Accessibility

- Semantic landmarks, skip-to-content link, visible focus rings.
- The project modal is a real dialog: focus is trapped inside it, `Escape` and
  backdrop click both close it, closing restores focus to the card that opened
  it, and background scroll is locked while it is open.
- The custom cursor dot is decorative, `pointer-events:none`, and disabled on
  touch/coarse-pointer devices.
- `prefers-reduced-motion: reduce` removes scroll-reveal animation, cursor lag
  and smooth scrolling — content still appears, just without motion.

## Verified before delivery

- [x] No horizontal overflow at 1884 / 1440 / 1280 / 1024 / 768 / 390 / 320px
- [x] All 9 project modals open, render and close with no console errors
- [x] Every card thumbnail rests at the same 46% opacity and lifts to full on
      hover — photo thumbs no longer sit brighter than generated ones
- [x] Syntax highlighting emits no leaked markup into visible text
- [x] Bank Churn modal shows all five captured report pages, Inventory
      Management all three, both with their public Publish-to-web links; no
      iframes anywhere on the page
- [x] Project modal traps focus, closes on Escape/backdrop, restores focus
- [x] Mobile nav opens/closes; reduced-motion keeps content visible
